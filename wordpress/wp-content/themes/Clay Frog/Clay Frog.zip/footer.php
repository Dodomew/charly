    <div class="footer-container">

        <div class="contact-me-block">
        
            <div class="contact-me-socialmedia">
            
                <img src="FB-f-Logo__blue_100.png">
            
            </div>
            
            <div class="contact-me-socialmedia">
            
                <img src="FB-f-Logo__blue_100.png">
            
            </div>
            
            <div class="contact-me-socialmedia">
            
                <img src="FB-f-Logo__blue_100.png">
            
            </div>
        
        </div>

    </div>

    <?php wp_footer(); //Crucial footer hook! ?>

    </body>

</html>